# README

1. git clone <repo>
2. npm install
3. bower install
4. gulp
5. git add, commit, push
